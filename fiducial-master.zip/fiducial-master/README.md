# Fiducial tracking demo

Spots 2 fiducials and draws a line between them.

Cribbed almost entirely from the [excellent python tutorials here](https://opencv-python-tutroals.readthedocs.org/en/latest/py_tutorials/py_feature2d/py_feature_homography/py_feature_homography.html#feature-homography).

Uses the [artag](http://www.artag.net/) fiducial markers.
